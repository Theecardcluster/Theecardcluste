
const typingText = document.getElementById("typing-text");
const phrases = ["Creative Developer 💡", "Tech Lover 👨‍💻", "Problem Solver 🔧", "Building for the Web 🌍"];
let i = 0, j = 0, currentPhrase = "", isDeleting = false;

function type() {
  if (i < phrases.length) {
    if (!isDeleting && j <= phrases[i].length) {
      currentPhrase = phrases[i].substring(0, j++);
    } else if (isDeleting && j >= 0) {
      currentPhrase = phrases[i].substring(0, j--);
    }

    typingText.innerHTML = currentPhrase;

    if (j === phrases[i].length) isDeleting = true;
    if (j === 0 && isDeleting) {
      isDeleting = false;
      i = (i + 1) % phrases.length;
    }

    setTimeout(type, isDeleting ? 50 : 120);
  }
}

type();
